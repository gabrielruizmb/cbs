package com.crisballon.features.order;

import java.util.List;

import javax.persistence.EntityManager;

import com.crisballon.configs.CustomizerFactory;

public class OrderRepository {
    
    public void create(Order order) {
        EntityManager em = CustomizerFactory.getEntityManager();
        try {
            em.getTransaction().begin();
            em.persist(order);
            em.flush();
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            throw e;
        } finally {
            em.close();
        }
    }

    public void update(Order order) {
        EntityManager em = CustomizerFactory.getEntityManager();
        try {
            em.getTransaction().begin();
            em.merge(order);
            em.flush();
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            throw e;
        } finally {
            em.close();
        }
    }

    public List<Order> getAll() {
        EntityManager em = CustomizerFactory.getEntityManager();
        try {
            return em.createQuery("SELECT o FROM Order o", 
                                Order.class).getResultList();
        } finally {
            em.close();
        }
    }

    public Order getById(Long id) {
        EntityManager em = CustomizerFactory.getEntityManager();
        try {
            return em.find(Order.class, id);
        } finally {
            em.close();
        }
    }

    public void delete(Order order) {
        EntityManager em = CustomizerFactory.getEntityManager();
        try {
            em.getTransaction().begin();
            Order managedOrder = em.find(Order.class, order.getId());
            if (managedOrder != null) {
                em.remove(managedOrder);
            }
            em.getTransaction().commit();
        } finally {
            em.close();
        }
    }

    public List<Order> getPendingOrders() {
        EntityManager em = CustomizerFactory.getEntityManager();
        try {
            return em.createQuery("SELECT o FROM Order o WHERE o.confirmed = false OR o.confirmed IS NULL", 
                                Order.class).getResultList();
        } finally {
            em.close();
        }
    }

    public List<Order> getConfirmedSales() {
        EntityManager em = CustomizerFactory.getEntityManager();
        try {
            return em.createQuery("SELECT o FROM Order o WHERE o.confirmed = true", 
                                Order.class).getResultList();
        } finally {
            em.close();
        }
    }
}
