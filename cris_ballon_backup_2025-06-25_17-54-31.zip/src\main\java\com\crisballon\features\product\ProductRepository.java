package com.crisballon.features.product;

import java.util.List;
import javax.persistence.EntityManager;
import com.crisballon.configs.CustomizerFactory;

public class ProductRepository {
    
    public void create(Product product) {
        EntityManager em = CustomizerFactory.getEntityManager();
        try {
            em.getTransaction().begin();
            em.persist(product);
            em.flush();
            em.getTransaction().commit();
        } finally {
            em.close();
        }
    }

    public void update(Product product) {
        EntityManager em = CustomizerFactory.getEntityManager();
        try {
            em.getTransaction().begin();
            em.merge(product);
            em.flush();
            em.getTransaction().commit();
        } finally {
            em.close();
        }
    }

    public List<Product> getAll() {
        EntityManager em = CustomizerFactory.getEntityManager();
        try {
            return em.createQuery("SELECT p FROM Product p", Product.class).getResultList();
        } finally {
            em.close();
        }
    }

    public Product getById(Long id) {
        EntityManager em = CustomizerFactory.getEntityManager();
        try {
            return em.find(Product.class, id);
        } finally {
            em.close();
        }
    }

    public void delete(Product product) {
        EntityManager em = CustomizerFactory.getEntityManager();
        try {
            em.getTransaction().begin();
            Product managedProduct = em.find(Product.class, product.getId());
            if (managedProduct != null) {
                em.remove(managedProduct);
            }
            em.getTransaction().commit();
        } finally {
            em.close();
        }
    }
}
