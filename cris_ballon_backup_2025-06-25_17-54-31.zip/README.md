# Sistema da Cris Ballon

  Sistema de gerenciamento de clientes e pedidos de arranjos de festa com balões e enfeites!

 - Para contribuir clone o projeto para uma pasta desejada, ex:
 - /Documentos/desenvolvimento: git clone git@github.com:gabrielruizmb/cbs.git

 - Em seguida entre no repositório e crie sua branch, ex:
 - /Documentos/desenvolvimento/cbs: git checkout -b meunome

 - Crie um banco de dados pertencente a um usuário, estas informações devem estar no arquivo hibernate.cfg.xml
   
