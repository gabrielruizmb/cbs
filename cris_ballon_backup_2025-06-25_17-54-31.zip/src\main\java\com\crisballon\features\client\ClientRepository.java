package com.crisballon.features.client;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import com.crisballon.configs.CustomizerFactory;

public class ClientRepository {

    public void create(Client client) {
        EntityManager em = CustomizerFactory.getEntityManager();
        try {
            em.getTransaction().begin();
            em.persist(client);
            em.flush(); // Força a gravação imediata
            em.getTransaction().commit();
            System.out.println("Cliente salvo: " + client.getName());
        } catch (Exception e) {
            em.getTransaction().rollback();
            System.out.println("Erro ao salvar cliente: " + e.getMessage());
            throw e;
        } finally {
            em.close();
        }
    }

    public Client getById(Long id) {
        EntityManager em = CustomizerFactory.getEntityManager();
        try {
            return em.find(Client.class, id);
        } finally {
            em.close();
        }
    }

    public List<Client> getAll() {
        EntityManager em = CustomizerFactory.getEntityManager();
        try {
            TypedQuery<Client> query = em.createQuery("SELECT c FROM Client c", Client.class);
            return query.getResultList();
        } finally {
            em.close();
        }
    }

    public void update(Client client) {
        EntityManager em = CustomizerFactory.getEntityManager();
        try {
            em.getTransaction().begin();
            em.merge(client);
            em.flush(); // Força a gravação imediata
            em.getTransaction().commit();
        } finally {
            em.close();
        }
    }

    public void delete(Client client) {
        EntityManager em = CustomizerFactory.getEntityManager();
        try {
            em.getTransaction().begin();
            Client managedClient = em.contains(client) ? client : em.merge(client);
            em.remove(managedClient);
            em.getTransaction().commit();
        } finally {
            em.close();
        }
    }
}
